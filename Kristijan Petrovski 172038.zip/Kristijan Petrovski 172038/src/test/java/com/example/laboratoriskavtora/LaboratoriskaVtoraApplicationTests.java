package com.example.laboratoriskavtora;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LaboratoriskaVtoraApplicationTests {

    @Test
    void contextLoads() {
    }

}
