package com.example.laboratoriskavtora.service;

import com.example.laboratoriskavtora.model.User;

public interface UserService {
    User findById(String userId);
}
