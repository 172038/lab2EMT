package com.example.laboratoriskavtora.model.enumerations;

public enum CartStatus {
    CREATED, CANCELED, FINISHED
}
