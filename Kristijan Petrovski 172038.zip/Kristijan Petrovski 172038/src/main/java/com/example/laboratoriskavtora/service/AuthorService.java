package com.example.laboratoriskavtora.service;

import com.example.laboratoriskavtora.model.Author;

public interface AuthorService {
    Author findById(Long authorId);
}
